Here be the home of the web-module.

The demonstration webapp has been moved to the activemq-web-demo module.
This module now only builds the jar for activemq-web.
The javascript modules needed for the AJAX interface are included as 
resources and served my the MessageListenerServlet

