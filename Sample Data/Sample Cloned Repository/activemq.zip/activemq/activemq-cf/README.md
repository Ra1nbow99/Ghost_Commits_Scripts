# Activemq-cf

Allows to create a Pooled ActiveMQ ConnectionFactory from a config.

## Install

Install the activemq-client and scr features and this bundle. Then put the example config org.apache.karaf.activemq.cfg in etc.

	service:list ConnectionFactory

This should show the ConnectionFactory as a service.
