This folder contains the logo and fugure images used by ActiveMQ:

![ActiveMQ Logo](logo-1024.png)
